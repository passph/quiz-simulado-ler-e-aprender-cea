
import { useState } from "react";

const questions = [
  {
    question: "Admita que um importador tenha comprado 1.400 contratos de dólar futuro... O importador obteve na operação:",
    options: [
      "A. prejuízo de R$ 5.978.000.",
      "B. lucro de R$ 119.560.",
      "C. prejuízo de R$ 119.560.",
      "D. Lucro de R$5.978,00"
    ],
    answer: 1
  },
  {
    question: "Com base no demonstrativo financeiro de uma empresa comercial: O EBITDA dessa empresa é:",
    options: [
      "A. R$ 5.000,00",
      "B. R$ 10.000,00",
      "C. R$ 9.000,00",
      "D. R$ 6.000,00"
    ],
    answer: 1
  }
  // Adicione o restante das questões aqui como no projeto real
];

export default function Home() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [finished, setFinished] = useState(false);

  const currentQuestion = questions[current];

  const handleAnswer = (index) => {
    setSelected(index);
    setShowAnswer(true);
    if (index === currentQuestion.answer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    setShowAnswer(false);
    setSelected(null);
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
    } else {
      setFinished(true);
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: 'auto' }}>
      {!finished ? (
        <>
          <h2>Questão {current + 1}</h2>
          <p>{currentQuestion.question}</p>
          <div>
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                style={{
                  display: 'block',
                  width: '100%',
                  margin: '5px 0',
                  backgroundColor: showAnswer
                    ? index === currentQuestion.answer
                      ? '#d4edda'
                      : selected === index
                      ? '#f8d7da'
                      : ''
                    : '',
                }}
                disabled={showAnswer}
              >
                {option}
              </button>
            ))}
          </div>
          {showAnswer && <button onClick={handleNext}>Próxima</button>}
        </>
      ) : (
        <div>
          <h2>Simulado finalizado!</h2>
          <p>Você acertou {score} de {questions.length} questões.</p>
        </div>
      )}
    </div>
  );
}
